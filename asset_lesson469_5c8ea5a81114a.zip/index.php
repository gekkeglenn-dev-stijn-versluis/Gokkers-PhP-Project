<?php require 'header.php'; ?>

   <h1>Welcome to AMO Login system Home Page! </h1>
   <p>Nothing special to see here but that's not the point.</p>
   <p>Try going to the ultra secret ultimate vip <a href='admin.php'> admin </a> page without logging in first</p>

<?php require 'footer.php'; ?>